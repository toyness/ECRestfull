import express, { Application } from 'express';
import { createOrder, getOrder } from './order.controller';

const app: Application = express();
const port = 3002;

app.use(express.json());

app.post('/api/orders', createOrder);
app.get('/api/orders/:id', getOrder);

app.listen(port, () => {
  console.log(`Order service listening on port ${port}`);
});