import { Request, Response } from 'express';

export const createOrder = async (req: Request, res: Response) => {
  // TO DO: implement logic to create new order
  res.send('Order created successfully');
};

export const getOrder = async (req: Request, res: Response) => {
  // TO DO: implement logic to retrieve order
  res.send('Order retrieved successfully');
};