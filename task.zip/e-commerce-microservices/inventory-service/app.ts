import express, { Application } from 'express';
import { getInventory, updateInventory, addInventory } from './inventory.controller';

const app: Application = express();
const port = 3001;

app.use(express.json());

app.get('/api/inventory', getInventory);
app.put('/api/inventory', updateInventory);
app.post('/api/inventory', addInventory);

app.listen(port, () => {
  console.log(`Inventory service listening on port ${port}`);
});