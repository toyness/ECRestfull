import { Request, Response } from 'express';

export const getInventory = async (req: Request, res: Response) => {
  // TO DO: implement logic to retrieve inventory
  res.send('Inventory retrieved successfully');
};

export const updateInventory = async (req: Request, res: Response) => {
  // TO DO: implement logic to update inventory
  res.send('Inventory updated successfully');
};

export const addInventory = async (req: Request, res: Response) => {
  // TO DO: implement logic to add new inventory
  res.send('Inventory added successfully');
};