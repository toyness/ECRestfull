
# E-Commerce Microservices Architecture

This project demonstrates a basic e-commerce microservices architecture using Docker, Node.js, and TypeScript. The architecture consists of two microservices:

- Inventory Service: responsible for managing product inventory

- Order Service: responsible for managing customer orders

## Acknowledgements

 - [Setup Instructions]()
 - [Usage]()
 - [Order Service]()
 - [Design Explanations]()


#### Setup Instructions


To set up the project, follow these steps:

- Clone the repository to your local machine.
- Install Docker and Docker Compose on your local machine.
- Navigate to the project directory and run the following command to build and start the containers:

````

docker-compose up --build

````
- Once the containers are up and running, you can access the services using the following URLs:

Inventory Service: ```` http://localhost:3001/api/inventory````

Order Service: ```` http://localhost:3002/api/orders````

#### Usage

Here are some example usage scenarios:

##### Inventory Service

- Create a new product inventory:

```` curl -X POST -H "Content-Type: application/json" -d '{"item": "Item 1", "stock": 10}' http://localhost:3001/api/inventory ````

- Retrieve a product inventory:

````curl -X GET http://localhost:3001/api/inventory````

#### Order Service

- Create a new customer order:

````curl -X POST -H "Content-Type: application/json" -d '{"item": "Item 1", "quantity": 2}' http://localhost:3002/api/orders````

- Retrieve a customer order:

````curl -X GET http://localhost:3002/api/orders/1````

#### Design Explanations

This project uses a microservices architecture, where each service is responsible for a specific domain logic. The services communicate with each other using RESTful APIs.

The Inventory Service uses a MongoDB database to store product inventory data. The Order Service uses a RabbitMQ message broker to communicate with the Inventory Service and retrieve product inventory data.

The project uses Docker and Docker Compose to containerize and orchestrate the services. This allows for easy deployment and scaling of the services.
## 🚀 About Me
I'm a Experienced software engineer with a proven track record of developing cutting-edge applications, collaborating with cross-functional teams, and mentoring junior engineers.


## Authors

- [@toyness](https://github.com/toyness)

